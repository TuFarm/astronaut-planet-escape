package gamestate;

public enum Gamestate {
   PLAYING, MENU;
	
	public static Gamestate state = MENU;
}
